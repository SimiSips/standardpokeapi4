package dev.ronnie.pokeapiandroidtask

import android.app.Application
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
class PokemonApp : Application()